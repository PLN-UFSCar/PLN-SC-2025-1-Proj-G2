package ter.util;

public class IntPair {
  public int car;
  public int cdr;
  public IntPair(int car, int cdr) {
    this.car = car;
    this.cdr = cdr;
  }
}
