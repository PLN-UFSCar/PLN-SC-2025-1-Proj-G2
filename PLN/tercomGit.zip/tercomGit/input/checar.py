def check_sgml(filename):
    ids = []
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line.startswith('<seg id='):
                start = line.find('"') + 1
                end = line.find('"', start)
                seg_id = int(line[start:end])
                ids.append(seg_id)
    return ids

ids_ref = check_sgml('corpus10k.clean.sgml')
ids_hyp = check_sgml('corpus10k.output.sgml')

print(f"Refs: {len(ids_ref)} segments, Hyps: {len(ids_hyp)} segments")

if ids_ref != ids_hyp:
    print("ERRO: IDs dos segmentos diferentes entre arquivos!")
else:
    print("IDs OK e em ordem.")
