import nltk
from nltk.util import ngrams
from collections import Counter
import re

# Certifique-se de que os dados do nltk estejam disponíveis
nltk.download('punkt')

def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^a-záàâãéèêíïóôõöúçñ ]', ' ', text)  # mantem apenas letras e espaços
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def extract_terms_from_reference(ref_path, min_freq=5):
    with open(ref_path, 'r', encoding='utf-8') as f:
        text = f.read()
    text = clean_text(text)
    tokens = nltk.word_tokenize(text)

    bigrams = ngrams(tokens, 2)
    trigrams = ngrams(tokens, 3)

    freq_bi = Counter(bigrams)
    freq_tri = Counter(trigrams)

    terms_bi = [' '.join(t) for t, c in freq_bi.items() if c >= min_freq]
    terms_tri = [' '.join(t) for t, c in freq_tri.items() if c >= min_freq]

    terms = set(terms_bi + terms_tri)

    with open('termos_extraidos.txt', 'w', encoding='utf-8') as f:
        for term in sorted(terms):
            f.write(term + '\n')

    return terms

def count_terms_in_hypothesis(terms, hyp_path):
    with open(hyp_path, 'r', encoding='utf-8') as f:
        hyp_text = f.read().lower()

    hyp_text = clean_text(hyp_text)

    count = sum(1 for term in terms if term in hyp_text)
    return count, len(terms)

def main():
    ref_path = 'corpus10k.clean.pt'
    hyp_path = 'corpus10k.output.pt'

    print("🔍 Extraindo termos frequentes do texto de referência...")
    terms = extract_terms_from_reference(ref_path, min_freq=5)

    print("📊 Calculando precisão terminológica...")
    found, total = count_terms_in_hypothesis(terms, hyp_path)
    precision = found / total if total > 0 else 0

    print(f'\n🎯 Precisão terminológica: {precision:.4f} ({found}/{total} termos encontrados)')

if __name__ == "__main__":
    main()
