import unicodedata
import re
import html

def clean_text(text):
    text = unicodedata.normalize('NFKC', text)
    text = text.replace('“', '"').replace('”', '"')
    text = text.replace('‘', "'").replace('’', "'")
    text = text.replace('–', '-').replace('—', '-')
    text = re.sub(r'[\u200B-\u200D\uFEFF]', '', text)
    text = text.strip()
    text = html.escape(text)
    return text

def txt_to_sgml(input_path, output_path):
    with open(input_path, 'r', encoding='utf-8') as fin, \
         open(output_path, 'w', encoding='utf-8') as fout:
        fout.write('<doc>\n')
        for i, line in enumerate(fin, 1):
            line = line.strip()
            if line:
                line = clean_text(line)
                fout.write(f'<seg id="{i}">{line}</seg>\n')
        fout.write('</doc>\n')

# Executa para os dois arquivos
txt_to_sgml('corpus10k.clean.pt', 'corpus10k.clean.sgml')
txt_to_sgml('corpus10k.output.pt', 'corpus10k.output.sgml')
